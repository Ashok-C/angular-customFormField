import { Component, OnInit, Input, forwardRef  } from '@angular/core';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';
import { FormGroup, FormBuilder, FormArray } from '@angular/forms';
import { __values } from '../../../node_modules/tslib';


@Component({
  selector: 'app-custom-control',
  templateUrl: './custom-control.component.html',
  styleUrls: ['./custom-control.component.css'],
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => CustomControlComponent),
    multi: true
  }]
})

export class CustomControlComponent implements  OnInit,ControlValueAccessor {
  
  _value: string = null;
  
  onChange: any = () => { };
  onTouched: any = () => { };

  nestedForm: FormGroup;

  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    
    this.nestedForm = this.fb.group({
      in_value: this.fb.array([this.fb.group({country:'', state:''})]),
      not_in_value: this.fb.array([this.fb.group({country:'', state:''})])
    });

    this.OnChanges();
  }

  get inValue() {
    return this.nestedForm.get('in_value') as FormArray;
  }

  addRowInValue() {
    this.inValue.push(this.fb.group({country:'', state:''}));
  }

  deleteRowInValue(index) {
    this.inValue.removeAt(index);
  }

  get notInValue() {
    return this.nestedForm.get('not_in_value') as FormArray;
  }

  addRowNotInValue() {
    this.notInValue.push(this.fb.group({country:'', state:''}));
  }

  deleteRowNotInValue(index) {
    this.notInValue.removeAt(index);
  }

  OnChanges(){
    this.nestedForm.valueChanges.subscribe(val =>{
      this.writeValue(val);
    });
  }
  get value() {
    return this._value;
  }

  set value(val) {
    this._value = val;
    this.onChange(val);
    this.onTouched();
  }

  registerOnChange(fn) {
    this.onChange = fn;
  }

  registerOnTouched(fn) { 
    this.onTouched = fn;
  }

  writeValue(value) {
    if (value) {
      this.value = value;
    }
  }
}
