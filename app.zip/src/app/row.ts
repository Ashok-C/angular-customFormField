export class Row {
    name: string
    row_details: RowFields[]
}

export class RowFields {
    country: string
    state: string
}